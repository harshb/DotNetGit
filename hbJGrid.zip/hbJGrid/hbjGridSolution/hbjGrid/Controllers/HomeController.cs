﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using hbjGrid.Models;

using System.Linq.Dynamic;

namespace hbjGrid.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to ASP.NET MVC!";

            return View();
        }

        public ActionResult About()
        {
            return View();
        }
        public JsonResult LinqGridData(string sidx, string sord, int page, int rows)
        {
            var context = new HaackOverflowDataContext();

            var jsonData = new
            {
                total = 1, //todo: calculate
                page = page,
                records = context.Questions.Count(),
                rows = (
                    from question in context.Questions
                    select new
                    {
                        i = question.Id,
                        cell = new string[] { question.Id.ToString(), question.Votes.ToString(), question.Title }
                    }).ToArray()
            };
            return Json(jsonData);
        }

        public JsonResult DynamicGridData(string sidx, string sord, int page, int rows)
        {
            var context = new HaackOverflowDataContext();
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            int totalRecords = context.Questions.Count();
            int totalPages = (int)Math.Ceiling((float)totalRecords / (float)pageSize);

            var questions = context.Questions.OrderBy(sidx + " " + sord).Skip(pageIndex * pageSize).Take(pageSize);

            var jsonData = new
            {
                total = totalPages,
                page,
                records = totalRecords,
                rows = (
                    from question in questions
                    select new
                    {
                        i = question.Id,
                        cell = new string[] { question.Id.ToString(), question.Votes.ToString(), question.Title }
                        //cell = new string[] { "", "", "", "" }
                    }).ToArray()
            };
            return Json(jsonData);
        }

        public JsonResult GridData(string sidx, string sord, int page, int rows)
        {
            int totalPages = 1; // we'll implement later
            int pageSize = rows;
            int totalRecords = 3; // implement later

            var jsonData = new
            {
                total = totalPages,
                page = page,
                records = totalRecords,
                rows = new[]{
                    new {id = 1, cell = new[] {"1", "-7", "Is this a good question?"}},
                    new {id = 2, cell = new[] {"2", "15", "Is this a blatant ripoff?"}},
                    new {id = 3, cell = new[] {"3", "23", "Why is the sky blue?"}}
                }
            };
            return Json(jsonData);
        }
    }
}
